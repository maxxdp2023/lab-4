export interface Car {
  id: number;
  img: string;
  name: string;
  price: number;
}
