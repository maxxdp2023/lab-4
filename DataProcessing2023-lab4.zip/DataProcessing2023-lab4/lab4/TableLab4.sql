CREATE TABLE "cars" (
  "id" serial PRIMARY KEY,
  "img" varchar(50),
  "name" varchar(50),
  "price" integer
);
